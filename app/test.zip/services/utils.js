var config = require('../../config');
var React = require('react-native');
var {
  NetInfo
} = React;

function url(path) {
  return config.api_host + (config.api_port ? ':' + config.api_port : '') + path;
}

exports.post = function(path, data) {
  data = data || {};
  return fetch(url(path), {
    method: 'POST',
    headers: {
      'Accept': 'application/json',
      'Content-Type': data instanceof FormData ? 'multipart/form-data' : 'application/json',
      'Connection': 'Keep-Alive'
    },
    body: data instanceof FormData ? data : JSON.stringify(data)
  }).then(function(res) {
    if (res.status !== 200) {
      // try to deserialize the error, otherwise just throw as text
      return res.json().then((error) => { throw error; }, () => { throw new Error(res._bodyText) });
    } else {
      return res.json().catch((e) => { return {ok: true}; });
    }
  }).catch(function(err) {
    console.log(err);
    throw err;
  });
};

exports.get = function(path) {
  return fetch(url(path), {
    method: 'GET',
    headers: {
      'Accept': 'application/json',
      'Content-Type': 'application/json'
    }
  }).then(function(res) {
    if (res.status !== 200) {
      // try to deserialize the error, otherwise just throw as text
      return res.json().then((error) => { throw error; }, () => { throw new Error(res._bodyText) });
    } else {
      return res.json().catch((e) => { return {ok: true}; });
    }
  }).catch(function(err) {
    console.log(err);
    throw err;
  });
};

function sleep(ms = 0) {
  return new Promise(r => setTimeout(r, ms));
}

exports.durable = function(tasks) {
  // Execute web service requests in a durable manner
  // That is, if a task fails due to a connection issue, leave it in the queue and try again when the connection returns
  // NOTE: tasks must be idempotent

  function isConnected() {
    return NetInfo.isConnected.fetch();
  }

  return new Promise(function(resolve, reject) {
    async function runTasks() {
      if (tasks.length === 0) {
        // base case
        return resolve(null);
      } else if (await isConnected()) {
        // we're connected, run the next task (using shift to preserve the task order)
        var task = tasks.shift();
        try {
          await task();
        } catch(e) {
          await sleep(100); // sometimes the exception is thrown before NetInfo knows about the connection
          if (!(await isConnected())) {
            // task failed due to bad connection (most likely), re-enqueue the task
            tasks.unshift(task);
          } else {
            return reject(e);
          }
        }
        runTasks();
      }
    }

    function handleConnectivityChange(isConnected) {
      if (isConnected) {
        // resume task processing
        runTasks()
      }
    }

    NetInfo.isConnected.addEventListener(
      'change',
      handleConnectivityChange
    );

    runTasks();
  });
};

exports.formatMoney = function(value) {
  if (value != null) {
    value = value.toString();
    value = value.replace(/[^0-9]/g, '');
    var num = value.replace(/,/gi, '');
    var num2 = num.replace(/\d(?=(?:\d{3})+$)/g, '$&,');
    return '$' + num2;
  } else {
    return 'N/A';
  }
};

exports.moneyToInt = function(string) {
  if (string) {
    var num = parseInt(string.replace(/[^0-9]/g, ''));
    if (isNaN(num)) {
      return 0;
    }
    return num;
  } else {
    return 0;
  }
};
