var utils = require('./utils');
var localStorage = require('./localStorage.service');
var userService = require('./user.service');
var analytics = require('./analytics.service');

var AuthService = {
  signup: async function(data) {
    var user;
    // if no data, use the local user wip
    if (!data) {
      var userWip = await localStorage.wip.user.get();
      // do transformations here
      userWip.sell_car = {};
      user = await utils.post('/api/auth/local/signup', userWip);
    } else {
      user = await utils.post('/api/auth/local/signup', data);
    }
    if (user && user.user_id) {
      analytics.identify(user.user_id);
    }
    return user;
  },
  login: function(email, password) {
    email = email.toLowerCase();
    return utils.post('/api/auth/local/login', {email: email, password: password})
      .then(function(user) {
        if (user && user.user_id) {
          analytics.identify(user.user_id);
        }
        return user;
      });
  },
  logout: function() {
    return utils.post('/api/auth/logout');
  },
  isLoggedIn: function() {
    return userService.get()
      .then(function(user) {
        return user && user.id ? user : false;
      })
      .catch(function() {
        return false;
      });
  }
};

module.exports = AuthService;
