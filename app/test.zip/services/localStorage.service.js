var React = require('react-native');
var {
  AsyncStorage,
} = React;
var fileService = require('../services/file.service');


var LISTING_WIP_KEY = 'listing-wip';
var USER_WIP_KEY = 'user-wip';
var IMAGE_WIP_KEY_PREFIX = 'images-';

var _removeOnClear = [
  LISTING_WIP_KEY,
  IMAGE_WIP_KEY_PREFIX+LISTING_WIP_KEY
];

function _setObject(key, object) {
  return AsyncStorage.setItem(key, JSON.stringify(object))
    .then(() => {
      return object;
    });
}

function _getObject(key) {
  return AsyncStorage.getItem(key)
    .then((item) => {
      return item ? JSON.parse(item) : null;
    });
}

// build work-in-progress module for specified key
function buildWIP(key) {
  return {
    upsert: function(options) {
      var self = this;
      return this.get()
        .then(function(object) {
          if (object) {
            return self.update(options);
          } else {
            return _setObject(key, options);
          }
        });
    },
    update: function(options) {
      return _getObject(key)
        .then((object) => {
          object = Object.assign(object, options);
          return _setObject(key, object);
        });
    },
    get: function() {
      return _getObject(key);
    },
    addImage: function(name, uri, category) {
      var imageKey = IMAGE_WIP_KEY_PREFIX + key;
      return _getObject(imageKey)
        .then((images) => {
          if (!images) {
            images = {};
          } else if (images[name] && images[name].uri != uri) {
            // Clean up the old image
            return fileService.remove(images[name].uri)
              .then(() => {
                return images;
              });
          }
          return images;
        })
        .then((images) => {
          images[name] = {
            uri: uri,
            category: category
          };
          return _setObject(imageKey, images);
        });
    },
    getImages: function() {
      var imageKey = IMAGE_WIP_KEY_PREFIX + key;
      return _getObject(imageKey);
    }
  };
}

exports.wip = {
  listing: buildWIP(LISTING_WIP_KEY),
  user: buildWIP(USER_WIP_KEY)
};

exports.setObject = function(key, object, removeOnClear) {
  if (removeOnClear) {
    _removeOnClear.push(key);
  }
  return _setObject(key, object);
};

exports.getObject = function(key) {
  return _getObject(key);
};

exports.set = function(key, str, removeOnClear) {
  if (removeOnClear) {
    _removeOnClear.push(key);
  }
  return AsyncStorage.setItem(key, str);
};

exports.get = function(key) {
  return AsyncStorage.getItem(key);
};

exports.clear = function() {
  return AsyncStorage.multiRemove(_removeOnClear);
};

// EXAMPLES
/*
local.wip.user.upsert({ first_name: 'Andrew', last_name: 'Crowell' });
local.wip.user.update({ zip: 98122 });
local.wip.user.get();

local.setObject('ENV', { currentSceneId: 'some-id' });
*/
