exports.PERMISSION_NAVIGATE = "permission_navigate";
