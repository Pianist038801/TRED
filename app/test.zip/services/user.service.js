var utils = require('./utils');

var UserService = {
  get: function() {
    return utils.get('/api/user');
  },
  update: function(data) {
    return utils.post('/api/user', data);
  }
};

module.exports = UserService;
