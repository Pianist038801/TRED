'use strict';

var Platform = require('react-native').Platform;

if (Platform.OS === 'android') {

} else {
  var PushNotificationIOS = require('react-native').PushNotificationIOS;
  PushNotificationIOS.requestPermissions();
}

exports.scheduleSellReminder = function() {
  if (Platform.OS === 'android') {

  } else {
    //PushNotificationIOS.cancelAllLocalNotifications();
    //PushNotificationIOS.scheduleLocalNotification({
    //  fireDate: Date.now() + 5000,
    //  alertBody: "Don't forget to sell your car!",
    //  //soundName: require('../../sounds/honk.wav')
    //});
  }
};

exports.cancelSellReminder = function() {
  if (Platform.OS === 'android') {

  } else {
    PushNotificationIOS.cancelAllLocalNotifications();
  }
};
