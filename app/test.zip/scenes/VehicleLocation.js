/**
 * TRED Vehicle Location Screen Component
 * https://www.tred.com
 * Sean Jackson (seanjackson@tred.com)
 * Novemeber, 2015
 */
'use strict';

var React = require('react-native');
var {
  View,
  ScrollView,
  Text,
  Image,
  TouchableOpacity,
  Platform,
  TextInput,
  SegmentedControlIOS,
  Alert,
  Button,
} = React;

var Button = require('apsl-react-native-button');
var KeyboardHandler = require('../components/KeyboardHandler.js');
var LocalStorage = require('../services/localStorage.service.js');
var InputAccessory = require('../components/InputAccessory.js');
var analytics = require('../services/analytics.service');

var styles = Platform.OS === 'android' ?
  require('../styles/baseStylesAndroid') : require('../styles/baseStylesIOS');

var VehicleLocation = React.createClass({
  getInitialState: function(){
    return {
      same_as_day: null,
      day_street: null,
      day_city: null,
      day_state: null,
      day_zip: null,
      night_street: null,
      night_city: null,
      night_state: null,
      night_zip: null,
      disabled: false,
      enableInputAccessory: false,
      currentZipField: null,
    };
  },
  componentDidMount: function(){
    analytics.visited('VehicleLocation');
    var component = this;
    var listing = null;
    LocalStorage.wip.listing.get().then(function(_listing){
      listing = _listing;
      return LocalStorage.wip.user.get();
    }).then(function(user){
      component.setState({
        same_as_day: typeof listing.same_as_day !== 'undefined' && listing.same_as_day !== null ? listing.same_as_day : true,
        day_street: listing.day_street,
        day_city: listing.day_city,
        day_state: listing.day_state || 'WA',
        day_zip: listing.day_zip || user.zip,
        night_street: listing.night_street,
        night_city: listing.night_city,
        night_state: listing.night_state || 'WA',
        night_zip: listing.night_zip
      });
      if(!listing || !listing.day_street){
        component.refs.day_street.focus();
      }
    });
  },
  onSameAsDay: function(value){
    this.setState({
      same_as_day: value === "Yes" ? true : false
    });
    if(this.refs['night_street']){
      this.refs['night_street'].focus();
    }
  },
  onZipField: function(){
    if(this.state.currentZipField === "day_zip" && !this.state.same_as_day){
      this.refs.night_street.focus();
    } else {
      this.refs.day_zip.blur();
    }
    if(this.state.currentZipField === "night_zip"){
      this.refs.night_zip.blur();
    }
  },
  validateZip: function(zip){
    if(typeof zip !== 'undefined' && zip && zip.length > 0 && zips.indexOf(zip) == -1) {
      return false;
    }
    return true;
  },
  hasErrors: function(){
    var error = null;
    if(!this.state.day_street){
      error = {msg:"You're missing the daytime street address for this vehicle.", field:"day_street"};
      return error;
    } else if (!this.state.day_city) {
      error = {msg:"You're missing the daytime city for this vehicle.", field:"day_city"};
      return error;
    } else if (!this.state.day_state) {
      error = {msg:"You're missing the daytime state for this vehicle.", field:"day_state"};
      return error;
    } else if (!this.state.day_zip) {
      error = {msg:"You're missing the daytime zip code for this vehicle.", field:"day_zip"};
      return error;
    }
    if(!this.state.same_as_day){
      if(!this.state.night_street){
        error = {msg:"You're missing the nighttime street address.", field:"night_street"};
        return error;
      } else if (!this.state.night_city) {
        error = {msg:"You're missing the nighttime city.", field:"night_city"};
        return error;
      } else if (!this.state.night_state) {
        error = {msg:"You're missing the nighttime state.", field:"night_state"};
        return error;
      } else if (!this.state.night_zip) {
        error = {msg:"You're missing the nighttime zip code.", field:"night_zip"};
        return error;
      }
    }
    return error;
  },
  onConfirm: function(){
    var component = this;    
    this.setState({disabled: true});
    var error = this.hasErrors();
    if(!error){
      LocalStorage.wip.listing.update({ 
        same_as_day: this.state.same_as_day,
        day_street: this.state.day_street,
        day_city: this.state.day_city,
        day_state: this.state.day_state || 'WA',
        day_zip: this.state.day_zip,
        night_street: this.state.night_street,
        night_city: this.state.night_city,
        night_state: this.state.night_state || 'WA',
        night_zip: this.state.night_zip,       
      }).then(function(){
        LocalStorage.wip.user.upsert({ zip: component.state.day_zip }).then(function() {
          component.setState({disabled: false});
          component.props.navigator.push({
            id: 'LoanInfo',
            name: 'Loan Information',
          });    
        }, function(){
          alert("An error occurred creating a local user.");
        });
      });
    } else {
      this.setState({disabled: false});
      Alert.alert("Uh Oh...", error.msg, [
        {text: "Fix", onPress: () => {
            setTimeout(() =>{
              component.refs[error.field].focus()
            }, 250);
          }
        }
      ]);      
    }
  },
  render: function() {
    var component = this;
    return (
      <View style={styles.main}>
        <KeyboardHandler ref='kh' offset={110}>
          <View style={[styles.content, {paddingHorizontal:0}]}>
            <Text style={styles.cameraTitle}>VEHICLE LOCATION</Text>
            <Text style={styles.subText}>We&apos;d like to prep test drive logistics.</Text>
            
            <Text style={[styles.h4, {marginTop:0}]}>DAYTIME LOCATION OF CAR</Text>
            <View style={styles.formField}>
              <Text style={[styles.label]}>Street Address</Text>
              <TextInput
                ref="day_street"
                autoFocus={false}
                autoCapitalize='words'
                returnKeyType='next'
                enablesReturnKeyAutomatically={true}
                selectTextOnFocus={true}
                style={[styles.textInput]}
                onChangeText={(day_street) => this.setState({day_street})}
                value={this.state.day_street}
                onSubmitEditing={()=>{this.refs.day_city.focus()}}
                onFocus={()=>this.refs['kh'].inputFocused(this,'day_street')} />
            </View>
            <View style={styles.formFieldHorizontal}>
              <Text style={[styles.label, styles.city]}>City</Text>
              <Text style={[styles.label, styles.state, {marginLeft:-5}]}>State</Text>
              <Text style={[styles.label, styles.zip]}>Zip</Text>
            </View>
            <View style={styles.formFieldHorizontal}>
              <TextInput
                ref="day_city"
                autoCapitalize='words'
                returnKeyType='next'
                enablesReturnKeyAutomatically={true}
                selectTextOnFocus={true}
                style={[styles.textInput, styles.city]}
                onChangeText={(day_city) => this.setState({day_city})}
                value={this.state.day_city} 
                onSubmitEditing={()=>{this.refs.day_state.focus()}}
                onFocus={()=>this.refs['kh'].inputFocused(this,'day_city')} />
              <TextInput
                ref="day_state"
                autoCapitalize='characters'
                returnKeyType='next'
                enablesReturnKeyAutomatically={true}
                selectTextOnFocus={true}
                style={[styles.textInput, styles.state]}
                onChangeText={(day_state) => this.setState({day_state})}
                value={this.state.day_state} 
                maxLength={2} 
                onSubmitEditing={()=>{this.refs.day_zip.focus()}}
                onFocus={()=>this.refs['kh'].inputFocused(this,'day_state')} />
              <TextInput
                ref="day_zip"
                keyboardType={Platform.OS === 'android' ? "numeric" : "number-pad"}
                enablesReturnKeyAutomatically={true}
                selectTextOnFocus={true}
                style={[styles.textInput, styles.zip]}
                onChangeText={(day_zip) => this.setState({day_zip})}
                value={this.state.day_zip} 
                maxLength={5}
                onFocus={()=>{
                  this.setState({
                    currentZipField: 'day_zip',
                    enableInputAccessory: true,
                  });
                  this.refs['kh'].inputFocused(this,'day_zip');
                }}
                onBlur={()=>{
                  this.setState({
                    currentZipField: null,
                    enableInputAccessory: false,
                  });
                }} />
            </View>

            <Text style={[styles.h4]}>NIGHTTIME LOCATION OF CAR</Text>
            { Platform.OS === 'android' ?
              <View style={styles.segment}>
                <View style={styles.segmentLabel}>
                  <Text style={styles.segmentText}>
                   Same as daytime address?
                  </Text>
                </View>
                <View style={styles.segmentControl}>
                  <Button style={[styles.segmentAndroid, this.state.same_as_day ? null : styles.segmentActive ]}
                    children="No"
                    onPress={() => {component.setState({same_as_day:false});}}
                    textStyle={[styles.segmentAndroidText, this.state.same_as_day ? null : styles.segmentActiveText]} />
                  <Button style={[styles.segmentAndroid, this.state.same_as_day ? styles.segmentActive: null]}
                    children="Yes"
                    onPress={() => {component.setState({same_as_day:true});}}
                    textStyle={[styles.segmentAndroidText, this.state.same_as_day ? styles.segmentActiveText: null]} />
                </View>
              </View>
            :
              <View style={styles.segment}>
                <View style={styles.segmentLabel}>
                  <Text style={styles.segmentText}>
                   Same as daytime address?
                  </Text>
                </View>
                <View style={styles.segmentControl}>
                  <SegmentedControlIOS 
                    ref="sameAsDay"
                    tintColor='#ffffff'
                    values={['No', 'Yes']}
                    selectedIndex={this.state.same_as_day ? 1 : 0}
                    onValueChange={this.onSameAsDay} />
                </View>
              </View>
            }
            {!this.state.same_as_day ? 
              <View>
                <View style={styles.formField}>
                  <Text style={[styles.label]}>Street Address</Text>
                  <TextInput
                    ref='night_street'
                    autoCapitalize='words'
                    returnKeyType='next'
                    enablesReturnKeyAutomatically={true}
                    selectTextOnFocus={true}
                    style={[styles.textInput]}
                    onChangeText={(night_street) => this.setState({night_street})}
                    value={this.state.night_street} 
                    onSubmitEditing={()=>{this.refs.night_city.focus()}}
                    onFocus={()=>this.refs['kh'].inputFocused(this,'night_street')} />
                </View>
                <View style={styles.formFieldHorizontal}>
                  <Text style={[styles.label, styles.city]}>City</Text>
                  <Text style={[styles.label, styles.state, {marginLeft:0}]}>State</Text>
                  <Text style={[styles.label, styles.zip]}>Zip</Text>
                </View>
                <View style={styles.formFieldHorizontal}>
                  <TextInput
                    ref="night_city"
                    autoCapitalize='words'
                    returnKeyType='next'
                    style={[styles.textInput, styles.city]}
                    enablesReturnKeyAutomatically={true}
                    selectTextOnFocus={true}
                    onChangeText={(night_city) => this.setState({night_city})}
                    value={this.state.night_city} 
                    onSubmitEditing={()=>{this.refs.night_state.focus()}}
                    onFocus={()=>this.refs['kh'].inputFocused(this,'night_city')} />
                  <TextInput
                    ref="night_state"
                    autoCapitalize='characters'
                    returnKeyType='next'
                    enablesReturnKeyAutomatically={true}
                    selectTextOnFocus={true}
                    style={[styles.textInput, styles.state]}
                    onChangeText={(night_state) => this.setState({night_state})}
                    value={this.state.night_state} 
                    maxLength={2} 
                    onSubmitEditing={()=>{this.refs.night_zip.focus()}}
                    onFocus={()=>this.refs['kh'].inputFocused(this,'night_state')} />
                  <TextInput
                    ref="night_zip"
                    keyboardType={Platform.OS === 'android' ? "numeric" : "number-pad"}
                    enablesReturnKeyAutomatically={true}
                    style={[styles.textInput, styles.zip]}
                    selectTextOnFocus={true}
                    onChangeText={(night_zip) => this.setState({night_zip})}
                    value={this.state.night_zip} 
                    maxLength={5}
                    onFocus={()=>{
                      this.setState({
                        currentZipField: 'night_zip',
                        enableInputAccessory: true,
                      });
                      this.refs['kh'].inputFocused(this,'night_zip');
                    }}
                    onBlur={()=>{
                      this.setState({
                        currentZipField: null,
                        enableInputAccessory: false,
                      });
                    }}
                    onSubmitEditing={this.onConfirm} />
                </View>
              </View> : null
            }
            <View ref="extra" style={{height:0}}></View>
          </View>
        </KeyboardHandler>
        <View style={styles.bottom}>
          <View style={styles.stretch}>
            <View style={styles.formField}>
              <Button onPress={this.onConfirm} style={[styles.actionButton, {marginHorizontal:15}]} textStyle={styles.actionButtonText} isDisabled={this.state.disabled}>
                CONTINUE
              </Button>
            </View>
          </View>
        </View>
        <InputAccessory buttonText='Next' onPress={this.onZipField} enabled={Platform.OS === 'android' ? false : this.state.enableInputAccessory}/>
      </View>
    );
  },
});

module.exports = VehicleLocation;
