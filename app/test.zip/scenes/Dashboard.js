/**
 * TRED Test Layout
 * https://www.tred.com
 * Sean Jackson (seanjackson@tred.com)
 * January, 2016
 */
'use strict';

var React = require('react-native');
var {
  View,
  Text,
  Image,
  Platform,
  ScrollView,
  StyleSheet
} = React;
var Button = require('apsl-react-native-button');
var analytics = require('../services/analytics.service');

var styles = Platform.OS === 'android' ?
  require('../styles/baseStylesAndroid') : require('../styles/baseStylesIOS');

var Test = React.createClass({
  render: function() {
    return (
      <View style={styles.main}>
        <ScrollView styles={styles.scroll}>
          <View style={styles.content}>
            <Text style={{marginTop:30, textAlign:'center'}}>DASHBOARD GOES HERE</Text>
          </View>
        </ScrollView>
      </View>
    );
  }
});
module.exports = Test;
