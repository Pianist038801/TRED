/**
 * TRED Log In Screen Component
 * https://www.tred.com
 * Sean Jackson (seanjackson@tred.com)
 * Novemeber, 2015
 */
'use strict';

var React = require('react-native');
var Button = require('apsl-react-native-button');
var {
  View,
  ScrollView,
  Text,
  Image,
  TouchableOpacity,
  Platform,
  LinkingIOS,
  IntentAndroid
} = React;
var localStorage = require('../services/localStorage.service');
var Intercom = require('react-native-intercom');
var version = require('../version/version.json');
var analytics = require('../services/analytics.service');

var styles = Platform.OS === 'android' ?
  require('../styles/baseStylesAndroid') : require('../styles/baseStylesIOS');

if(Platform.OS === 'android'){
  var ModalBox = require('react-native-modalbox');
  var WebView = require('react-native-webview-android');
} else {
  var Modal = require('react-native').Modal;
  var WebView = require('react-native').WebView;
}

var Support = React.createClass({
  getInitialState: function(){
    return {
      tosModalVisible: false,
      privacyModalVisible: false,
      aboutModalVisible: false,
      commitish: version.commitish,
      packageVersion: version.packageVersion
    };
  },
  componentDidMount: function() {
    analytics.visited('Support');
  },
  onPhone: function(){
    Platform.OS === 'android' ?
      IntentAndroid.openURL('tel:18557958733')
    :
      LinkingIOS.openURL('tel:18557958733');
  },
  onEmail: function(){
    Platform.OS === 'android' ?
      IntentAndroid.openURL('mailto:help@tred.com')
    :
      LinkingIOS.openURL('mailto:help@tred.com');
  },
  onIntercom: function(){
    if(Platform.OS === 'android'){
      Intercom.registerUnidentifiedUser();
    } 
    Intercom.displayMessageComposer();
  },
  showTOS: function(){
    this.setState({
      tosModalVisible: true
    });
  },
  hideTOS: function(){
    this.setState({
      tosModalVisible: false
    });
  },
  showPrivacy: function(){
    this.setState({
      privacyModalVisible: true
    });
  },
  hidePrivacy: function(){
    this.setState({
      privacyModalVisible: false
    });
  },
  showAbout: function(){
    this.setState({
      aboutModalVisible: true
    });
  },
  hideAbout: function(){
    this.setState({
      aboutModalVisible: false
    });
  },
  modalWebView: function(url, func, paddingTop){
    return (  
      <View style={[styles.main, {paddingTop:paddingTop, paddingBottom:50}]}>
        <View style={[styles.content, {flex:1, paddingHorizontal:0}]}>
          <WebView url={url} style={{flex:1}} startInLoadingState={true} loading={true} />
        </View>
        <View style={[styles.bottom, styles.extraBottom]}>
          <View style={styles.stretch}>
            <View style={styles.formField}>
              <Button onPress={func} style={[styles.actionButton, {flex:1, marginLeft:15}]} textStyle={styles.cancelButtonText}>
                CLOSE
              </Button>
            </View>
          </View>
        </View>
      </View>
    );
  },
  render: function() {
    var component = this;
    return (
      <View style={{flex:1}}>
        <View style={[styles.main, {paddingBottom:0}]}>
          <ScrollView style={styles.scroll}>
            <View style={styles.content}>
              <Text style={styles.titleText}>SUPPORT</Text>
              <Text style={[styles.subText, {marginTop:0}]}>We&apos;re here to help.</Text>
              <View style={styles.innerContainer}>
                <Image 
                  source={require('../../images/support.gif')}
                  style={[styles.supportImage, {marginVertical:5}]} />
              </View>
              <View style={{marginHorizontal:15}}>
                <Button onPress={component.onPhone} style={[styles.actionButton, {marginVertical:5, marginTop:10}]} textStyle={styles.supportButtonText}>
                  PHONE - (855) 795-8733
                </Button>
                <Button onPress={component.onEmail} style={[styles.tertiaryButton, {marginVertical:5, marginTop:0}]} textStyle={styles.supportButtonText}>
                  EMAIL - HELP@TRED.COM
                </Button>
                <Button onPress={component.onIntercom} style={[styles.secondaryButton, {marginVertical:5,marginTop:0}]} textStyle={styles.supportButtonText}>
                  CHAT ONLINE NOW
                </Button>
                <View style={{flex:1, flexDirection: "row", alignItems: "stretch", justifyContent:"center", marginBottom:30}}>
                  <TouchableOpacity onPress={component.showTOS}>           
                    <Text style={[styles.actionLinkSmall, {marginHorizontal:15, marginTop:15, textAlign:'center'}]}>
                      Terms of Use
                    </Text>
                  </TouchableOpacity>
                  <TouchableOpacity onPress={component.showPrivacy}>           
                    <Text style={[styles.actionLinkSmall, {marginHorizontal:15, marginTop:15, textAlign:'center'}]}>
                      Privacy Policy
                    </Text>
                  </TouchableOpacity>
                  <TouchableOpacity onPress={component.showAbout}>
                    <Text style={[styles.actionLinkSmall, {marginHorizontal:15, marginTop:15, textAlign:'center'}]}>
                      About
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>
            </View>
          </ScrollView>
        </View>
        {Platform.OS === 'android' ?
          <ModalBox style={styles.modal} background={false} isOpen={this.state.tosModalVisible} swipeToClose={false}>
            {this.modalWebView("https://www.tred.com/terms-of-use-mobile", this.hideTOS, -15)}
          </ModalBox>
        :
          <Modal
          style={{flex:1, alignItems:'flex-start'}}
            animated={true}
            transparent={false}
            visible={this.state.tosModalVisible}>
            {this.modalWebView("https://www.tred.com/terms-of-use-mobile", this.hideTOS, 10)}
          </Modal>
        }

       {Platform.OS === 'android' ?
          <ModalBox style={styles.modal} background={false} isOpen={this.state.privacyModalVisible} swipeToClose={false}>
            {this.modalWebView("https://www.tred.com/privacy-policy-mobile", this.hidePrivacy, -15)}
          </ModalBox>
        :
          <Modal
          style={{flex:1, alignItems:'flex-start'}}
            animated={true}
            transparent={false}
            visible={this.state.privacyModalVisible}>
            {this.modalWebView("https://www.tred.com/privacy-policy-mobile", this.hidePrivacy, 10)}
          </Modal>
        }

        {Platform.OS === 'android' ?
          <ModalBox style={styles.modal} background={false} isOpen={this.state.aboutModalVisible} swipeToClose={false}>
            <View style={[styles.main, {paddingTop:30}]}>
              <ScrollView style={styles.scroll}>
                <View style={[styles.content, {paddingHorizontal:0}]}>
                  <View style={[styles.table]}>
                    <View style={[styles.tableRow]}>
                      <View style={styles.tableCol60}>
                        <Text style={[styles.tableText]}>VCS Version</Text>
                      </View>
                      <View style={styles.tableCol40}>
                        <Text style={[styles.tableText, {fontWeight:'bold', textAlign:'right'}]}>{this.state.commitish}</Text>
                      </View>
                    </View>
                    <View style={[styles.tableRow]}>
                      <View style={styles.tableCol60}>
                        <Text style={[styles.tableText]}>Copyright</Text>
                      </View>
                      <View style={styles.tableCol40}>
                        <Text style={[styles.tableText, {fontWeight:'bold', textAlign:'right'}]}>2015-2016</Text>
                      </View>
                    </View>
                    <View style={[styles.tableRow, styles.tableBottom]}>
                      <View style={styles.tableCol60}>
                        <Text style={[styles.tableText]}>Version</Text>
                      </View>
                      <View style={styles.tableCol40}>
                        <Text style={[styles.tableText, {fontWeight:'bold', textAlign:'right'}]}>1.0.0</Text>
                      </View>
                    </View>
                  </View>
                </View>
              </ScrollView>
              <View style={[styles.bottom, styles.extraBottom]}>
                <View style={styles.stretch}>
                  <View style={styles.formField}>
                    <Button onPress={this.hideAbout} style={[styles.actionButton, {flex:1, marginLeft:15}]} textStyle={styles.cancelButtonText}>
                      CLOSE
                    </Button>
                  </View>
                </View>
              </View>
            </View>
          </ModalBox>
        :
          <Modal
            style={{flex:1, alignItems:'flex-start'}}
            animated={true}
            transparent={false}
            visible={this.state.aboutModalVisible}>
            <View style={[styles.main, {paddingTop:30}]}>
              <ScrollView style={styles.scroll}>
                <View style={[styles.content, {paddingHorizontal:0}]}>
                  <View style={[styles.table]}>
                    <View style={[styles.tableRow]}>
                      <View style={styles.tableCol60}>
                        <Text style={[styles.tableText]}>VCS Version</Text>
                      </View>
                      <View style={styles.tableCol40}>
                        <Text style={[styles.tableText, {fontWeight:'bold', textAlign:'right'}]}>{this.state.commitish}</Text>
                      </View>
                    </View>
                    <View style={[styles.tableRow]}>
                      <View style={styles.tableCol60}>
                        <Text style={[styles.tableText]}>Copyright</Text>
                      </View>
                      <View style={styles.tableCol40}>
                        <Text style={[styles.tableText, {fontWeight:'bold', textAlign:'right'}]}>2015-2016</Text>
                      </View>
                    </View>
                    <View style={[styles.tableRow, styles.tableBottom]}>
                      <View style={styles.tableCol60}>
                        <Text style={[styles.tableText]}>Version</Text>
                      </View>
                      <View style={styles.tableCol40}>
                        <Text style={[styles.tableText, {fontWeight:'bold', textAlign:'right'}]}>{this.state.packageVersion}</Text>
                      </View>
                    </View>
                  </View>
                </View>
              </ScrollView>
              <View style={styles.bottom}>
                <View style={styles.stretch}>
                  <View style={styles.formField}>
                    <Button onPress={this.hideAbout} style={[styles.actionButton, {flex:1, marginLeft:15}]} textStyle={styles.cancelButtonText}>
                      CLOSE
                    </Button>
                  </View>
                </View>
              </View>
            </View>
          </Modal>
        }
      </View>
    );
  }
});

module.exports = Support;
