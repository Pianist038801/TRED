/**
 * TRED Log In Screen Component
 * https://www.tred.com
 * Sean Jackson (seanjackson@tred.com)
 * Novemeber, 2015
 */
'use strict';

var React = require('react-native');
var Button = require('apsl-react-native-button');
var {
  View,
  ScrollView,
  Text,
  Image,
  TouchableOpacity,
  Platform,
  TextInput,
} = React;
var auth = require('../services/auth.service');
var userService = require('../services/user.service');
var listings = require('../services/listing.service');
var localStorage = require('../services/localStorage.service');
var Intercom = require('react-native-intercom');
var cropTool = require('react-native-crop-tool');

var styles = Platform.OS === 'android' ?
  require('../styles/baseStylesAndroid') : require('../styles/baseStylesIOS');

var LogIn = React.createClass({
  getInitialState: function(){
    return {
      loggedIn: null,
      email: null,
      password: null,
    };
  },
  componentDidMount: function(){
    localStorage.get('email')
      .then((email) => {
        if (email) {
          this.setState({
            email
          });
        }
      });
    userService.get()
      .then((user) => {
        this.setState({
          loggedIn: !!user.id
        });
      });
  },
  login: function() {
    return auth.login(this.state.email, this.state.password)
      .then(() => {
        localStorage.set('email', this.state.email);
        this.setState({
          loggedIn: true
        });
      })
      .catch((err) => {
        alert(err);
      });
  },
  logout: function() {
    return auth.logout()
      .then(() => {
        this.setState({
          loggedIn: false
        });
      })
      .catch((err) => {
        alert(err);
      });
  },
  test: function() {
    var vin = 'JM1NA3533R0501923'; //andrewj.crowell@gmail.com's car
    return localStorage.wip.listing.getImages()
      .then((images) => {
        return listings.uploadImage(vin, {category:'exterior'}, images.frontDriverCorner);
      })
      .then((res) => {
        alert(JSON.stringify(res));
      });
  },
  clear: function() {
    return localStorage.clear()
      .then(() => {
        alert('DONE!');
      });
  },
  onIntercom: function(){
    Intercom.displayMessageComposer();
  },
  crop: function() {
    return localStorage.wip.listing.getImages()
      .then((images) => {
        if (!images.frontDriverCorner) {
          alert('nope');
        }
        return cropTool.crop(images.frontDriverCorner, .6, 1);
      });
  },
  render: function() {
    var component = this;
    return (
      <ScrollView style={styles.container}>
        <Text style={styles.titleText}>TRED SUPPORT</Text>
        { component.state.loggedIn ?
          <Button onPress={component.logout} style={[styles.actionButton, {marginHorizontal:15}]} textStyle={styles.actionButtonText}>
            LOGOUT
          </Button>
        :
          <View style={styles.formField}>
            <Text style={[styles.label]}>Email</Text>
            <TextInput
              style={[styles.textInput]}
              onChangeText={(email) => this.setState({email})}
              value={this.state.email}
              keyboardType="email-address"
              autoCapitalize='none'
              autoCorrect={false} />
            <Text style={[styles.label]}>Password</Text>
            <TextInput
              style={[styles.textInput]}
              onChangeText={(password) => this.setState({password})}
              value={this.state.password}
              secureTextEntry={true}
              autoCapitalize='none'
              autoCorrect={false} />
            <Button onPress={component.login} style={[styles.actionButton, {marginHorizontal:15}]} textStyle={styles.actionButtonText}>
              LOGIN
            </Button>
          </View>
        }
        <Button onPress={component.test} style={[styles.actionButton, {marginHorizontal:15}]} textStyle={styles.actionButtonText}>
          UPLOAD TEST
        </Button>
        <Button onPress={component.clear} style={[styles.actionButton, {marginHorizontal:15}]} textStyle={styles.actionButtonText}>
          CLEAR LOCAL STORAGE
        </Button>
        <Button onPress={component.onIntercom} style={[styles.actionButton, {marginHorizontal:15}]} textStyle={styles.actionButtonText}>
          INTERCOM
        </Button>
        <Button onPress={component.crop} style={[styles.actionButton, {marginHorizontal:15}]} textStyle={styles.actionButtonText}>
          CROP IMAGE
        </Button>
      </ScrollView>
    );
  }
});

module.exports = LogIn;
