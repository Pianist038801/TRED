/**
 * TRED Test Layout
 * https://www.tred.com
 * Sean Jackson (seanjackson@tred.com)
 * January, 2016
 */
'use strict';

var React = require('react-native');
var {
  View,
  Text,
  Image,
  Platform,
  ListView,
  ScrollView,
  StyleSheet
} = React;
var Button = require('apsl-react-native-button');
var analytics = require('../../services/analytics.service');
var LoginModal = require('../../components/LoginModal');
var Listing = require('../../components/Listing');
var authService = require('../../services/auth.service');
var userService = require('../../services/user.service');

var styles = Platform.OS === 'android' ?
  require('../../styles/baseStylesAndroid') : require('../../styles/baseStylesIOS');

var Dashboard = React.createClass({
  getInitialState: function(){
    var ds = new ListView.DataSource({rowHasChanged: (r1, r2) => {
      return true;
    }});
    return {
      user: null,
      loggedIn: false,
      dataSource: ds.cloneWithRows([]),      
    };
  },

  componentDidMount: function(){
    var component = this;
    authService.isLoggedIn().then(function(loggedInUser) {
      component.setState({
        loggedIn: !!loggedInUser,
      });
      if(!loggedInUser){
        setTimeout(function(){
          component.showLoginModal();
        },200);
      } else {
        component.setUser();        
      }
    });
  },
  showLoginModal: function(){
    this.refs.loginModal.showLoginModal();
  },
  setUser: async function(){
    var user = await userService.get();
    this.setState({
      loggedIn: true,
      user: user
    });
  },
  onLogin: async function() {
    var user = await userService.get();
    analytics.track('Logged In');
    this.setState({
      loggedIn: true,
      user: user
    });
  },
  render: function() {
    if(this.state.user){
      var listings = this.state.user.listings;
      var listingsLength = listings.length;      
    }
    if(this.state.user){
      if(listingsLength !== 1){
        return (
          <View style={{flex:1}}>
            <View style={[styles.main, {paddingBottom:48}]}>
              <View style={[styles.content, {flex:1, paddingHorizontal:0}]}>
                <Text style={styles.cameraTitle}>CARS YOU’RE SELLING</Text>
                <View style={[styles.scroll, styles.listViewBackground]}>
                  <View style={{flex:1}}>
                    {listingsLength > 0 ?
                      <ListView
                        dataSource={this.state.dataSource}
                        renderRow={(rowData, sectionID, rowID) => 
                          <TouchableHighlight onPress={() => this.pressRow(rowID)}>
                            <View>
                              <View style={styles.listViewRow}>
                                <Text style={[styles.listViewText, rowData.isSelected ? styles.selectedRowText : null]}>
                                  Listing goes here
                                </Text>
                              </View>
                              <View style={styles.separator} />
                            </View>
                          </TouchableHighlight>
                        } />
                    :
                      <View>
                        <Text style={styles.listViewError}>NO LISTINGS FOUND.</Text>
                      </View>                  
                    }
                  </View>
                </View>
              </View>
              <View style={styles.bottom}>
                <View style={styles.stretch}>
                  <View style={styles.formField}>
                    <Button onPress={this.onConfirm} style={[styles.actionButton, {marginHorizontal:15}]} textStyle={styles.actionButtonText} isDisabled={this.state.disabled}>
                      SIGN OUT
                    </Button>
                  </View>
                </View>
              </View>
            </View>
          </View>
        );
      } else {
        return (
          <View style={{flex:1}}>
            <View style={styles.main}>
              <ScrollView styles={styles.scroll}>
                {this.state.user ?
                  <View style={styles.content}>
                    <Listing listing={listings[0]} />
                  </View>
                : 
                  null
                }
              </ScrollView>
            </View>
          </View>
        );
      }
    } else {
      return (
        <View style={{flex:1}}>
          <View style={styles.main}>
            <ScrollView styles={styles.scroll}>
              {this.state.user ?
                <View style={styles.content}>
                  <Text style={[styles.pText, {marginTop:15, textAlign:'center'}]}>Please sign in to view your dashboard.</Text>
                </View>
              : 
                null
              }
            </ScrollView>
          </View>
          <LoginModal ref="loginModal" onLogin={this.onLogin} navigator={this.props.navigator} showHome={true} />
        </View>
      );      
    }
  },
});
module.exports = Dashboard;
